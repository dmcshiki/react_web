function Asset(props) {
    return (<img src={props.asset}></img>);
}



export default Asset;