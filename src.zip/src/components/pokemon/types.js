function Types(props) {
    return (
        <div className="d-flex justify-content-center align-items-center">
            <h2>{props.types}</h2>
        </div>
    );
}



export default Types;