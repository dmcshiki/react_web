function Name(props) {
    return (
        <h1>{props.name}</h1>
    );
}



export default Name;